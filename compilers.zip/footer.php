<div class="row-fluid" id="footer"><br/>
		<center><a href="#"> &copy Pandian, Ashwin & Sathish </a></center><br/>
</div>