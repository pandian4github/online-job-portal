<div class="row-fluid" id="toprow">
	<div class="span2"></div>
	<div class="span8"><center><b>RESUME CLASSIFICATION</b></center></div>
	<div class="span2"></div>
</div>
	<br/>
<div class="row-fluid">
	<div class="span2 offset2" id="changepass"><br/>	
	</div>
	<div class="span4" id="main-head"><center><h2> R C app </h1><center> </div>
	<div class="span1 offset1" id="logout"><br/>	
	</div>
</div>


<div class="row-fluid">
	<div class="span2" id="leftsidebar">	
	</div>

