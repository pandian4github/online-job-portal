<?php
	$dbc=mysqli_connect('localhost','pim','pim','pim') or die("Couldn't connect to the database");
?>